<?php
// Config

$zone_id = 'f030023a66301bcb4adbdd813e66da83';