<?php
// Config

$zone_id = '6fba7b9677ad082597b2138a4b5c931a';